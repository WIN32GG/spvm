__version__ = 'UNKNOWN'  # FIXME UPDATE
